package com.example.laboratorio11.network.dto.login


data class LoginRequest (
    val email: String,
    val password: String
)