package com.example.laboratorio05.data.model

data class MovieModel (
    val name: String,
    val category: String,
    val description: String,
    val qualification: String,
)