package com.example.labo05

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.findFragment
import androidx.navigation.findNavController
import androidx.navigation.fragment.findNavController

class FirstFragment : Fragment(R.layout.fragment_first) {
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val btnNewM= requireView().findViewById<Button>(R.id.btnfirst)
        val btnMovi= requireView().findViewById<Button>(R.id.card1)

        btnNewM.setOnClickListener{
            findNavController().navigate(R.id.action_firstFragment_to_secondFragment)
        }

        btnMovi.setOnClickListener{
            findNavController().navigate(R.id.action_firstFragment_to_thirdFragment)
        }
    }
}