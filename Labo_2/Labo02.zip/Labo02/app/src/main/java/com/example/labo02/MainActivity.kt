package com.example.labo02

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btn:Button=findViewById(R.id.btn_1)
        btn.setOnClickListener{Calculate()}
    }

    private fun Calculate(){
        val weight_2:EditText=findViewById(R.id.weight_1)
        val height_2:EditText=findViewById(R.id.height_1)

        val weight_3:Double=weight_2.toString().toDouble()
        val height_3:Double=height_2.toString().toDouble()

        val bmi_2:Double=weight_3/height_3*(height_3)

    }
}