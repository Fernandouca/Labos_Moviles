package com.example.laboratorio05.repositories

import com.example.laboratorio05.data.dao.MovieDao
import com.example.laboratorio05.data.model.MovieModel

class MovieRepository(private val moviesDao: MovieDao) {

    suspend fun getMovies()= moviesDao.getAllMovies()
    suspend fun addMovies(movies: MovieModel)= moviesDao.insertMovie(movies)
    suspend fun getMoviesWithActor(id: Int)= moviesDao.getMovieWithActorById(id)
}