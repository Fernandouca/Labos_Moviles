package com.example.labo04

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class SecondActivity : AppCompatActivity() {
    private lateinit var text21: TextView
    private lateinit var text22: TextView
    private lateinit var text23: TextView
    private lateinit var btn2:Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)
        bind()
        clickListener()

        val Nombre=intent.getStringExtra("Nombre").toString()
        val Correo=intent.getStringExtra("Correo").toString()
        val Numero=intent.getStringExtra("Numero").toString()

        text21.text=Nombre
        text22.text=Correo
        text23.text=Numero
    }
    private fun bind(){
        text21=findViewById(R.id.text21)
        text22=findViewById(R.id.text22)
        text23=findViewById(R.id.text23)
    }
    private fun clickListener(){
        val shareIntent=Intent(Intent.ACTION_SEND)
        shareIntent.type="text/plain"
        shareIntent.putExtra(Intent.EXTRA_TEXT,"Name: $text21\nEmail: $text22\nPhone:$text23")
        startActivity(Intent.createChooser(shareIntent,"share to:"))
    }
}