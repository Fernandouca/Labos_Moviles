package com.example.labo04

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText


class MainActivity : AppCompatActivity() {
    private lateinit var textnombre:EditText
    private lateinit var textcorreo:EditText
    private lateinit var textnumero:EditText
    private lateinit var btn11:Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bind()
        clickListener()
        }
        private fun bind(){
            textnombre=findViewById(R.id.textnombre)
            textcorreo=findViewById(R.id.textcorreo)
            textnumero=findViewById(R.id.textnumero)
            btn11=findViewById(R.id.btn11)
        }

        private fun clickListener(){
            btn11.setOnClickListener{
                var intent=Intent(this,SecondActivity::class.java)
                intent.putExtra("Nombre",textnombre.text.toString())
                intent.putExtra("Correo",textcorreo.text.toString())
                intent.putExtra("Numero",textnumero.text.toString())
                startActivity(intent)
            }
        }
    }


